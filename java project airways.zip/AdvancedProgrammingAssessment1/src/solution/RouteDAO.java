package solution;
import java.nio.file.Path;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import baseclasses.DataLoadingException;
import baseclasses.IRouteDAO;
import baseclasses.Route;


/**
 * The RouteDAO parses XML files of route information, each route specifying
 * where the airline flies from, to, and on which day of the week
 */



public class RouteDAO implements IRouteDAO {
	
	ArrayList <Route> routes = new ArrayList<Route>();
	

	
    
	/**
	 * Finds all flights that depart on the specified day of the week
	 * @param dayOfWeek A three letter day of the week, e.g. "Tue"
	 * @return A list of all routes that depart on this day
	 */
	@Override
	public List<Route> findRoutesByDayOfWeek(String dayOfWeek) {
		// TODO Auto-generated method stub
		ArrayList<Route> route = new ArrayList<Route>();
		
		for(Route i: routes) {
					
					if(i.getDayOfWeek().equals(dayOfWeek)) {
						route.add(i);
			}
					
		}
				
		return route;
	}

	/**
	 * Finds all of the flights that depart from a specific airport on a specific day of the week
	 * @param airportCode the three letter code of the airport to search for, e.g. "MAN"
	 * @param dayOfWeek the three letter day of the week code to search for, e.g. "Tue"
	 * @return A list of all routes from that airport on that day
	 */
	@Override
	public List<Route> findRoutesByDepartureAirportAndDay(String airportCode, String dayOfWeek) {
		// TODO Auto-generated method stub
		
		ArrayList<Route> route = new ArrayList<Route>();
		
		
		for(Route i: routes) {
			
			if(i.getDepartureAirportCode().equals(airportCode)){
				
				if(i.getDayOfWeek().equals(dayOfWeek)) {
				
				route.add(i);
				
				}
			}
		}
			
		return route;
		
		
		
	}

	/**
	 * Finds all of the flights that depart from a specific airport
	 * @param airportCode the three letter code of the airport to search for, e.g. "MAN"
	 * @return A list of all of the routes departing the specified airport
	 */
	@Override
	public List<Route> findRoutesDepartingAirport(String airportCode) {
		// TODO Auto-generated method stub
		ArrayList<Route> route = new ArrayList<Route>();
		
		for(Route i: routes) {
			if(i.getDepartureAirportCode().equals(airportCode)) {
				route.add(i);
			}
		}
		return route;
	}

	/**
	 * Finds all of the flights that depart on the specified date
	 * @param date the date to search for
	 * @return A list of all routes that depart on this date
	 * 
	 * 
	 */ 
	
	DayOfWeek day;
	
	@Override
	public List<Route> findRoutesbyDate(LocalDate date) {
		// TODO Auto-generated method stub
		
		ArrayList<Route> route = new ArrayList<Route>();
		
		for(Route i: routes) {
					
					switch(i.getDayOfWeek()){
					 
					case "Sun":
						day = DayOfWeek.SUNDAY;
						break;
					case "Mon":
						day = DayOfWeek.MONDAY;
						break;
					case "Tue":
						day = DayOfWeek.TUESDAY;
						break;
					case "Wed":
						day = DayOfWeek.WEDNESDAY;
						break;
					case "Thu":
						day = DayOfWeek.THURSDAY;
						break;
					case "Fri":
						day = DayOfWeek.FRIDAY;
						break;
					case "Sat":
						day = DayOfWeek.SATURDAY;
						break;
						
						default:
							day = null;
			}
					
					if(day.equals(date.getDayOfWeek())) {
						route.add(i);
					}
					
		}
				
		return route;
	}
	

	/**
	 * Returns The full list of all currently loaded routes
	 * @return The full list of all currently loaded routes
	 */
	@Override
	public List<Route> getAllRoutes() {
		// TODO Auto-generated method stub
		return routes;
	}

	/**
	 * Returns The number of routes currently loaded
	 * @return The number of routes currently loaded
	 */
	@Override
	public int getNumberOfRoutes() {
		// TODO Auto-generated method stub
		return routes.size();
		
	}

	/**
	 * Loads the route data from the specified file, adding them to the currently loaded routes
	 * Multiple calls to this function, perhaps on different files, would thus be cumulative
	 * @param p A Path pointing to the file from which data could be loaded
	 * @throws DataLoadingException if anything goes wrong. The exception's "cause" indicates the underlying exception
	 */
	@Override
	public void loadRouteData(Path p) throws DataLoadingException {
		
		try {
			
			DocumentBuilder db = DocumentBuilderFactory.newInstance().newDocumentBuilder();
			Document doc = db.parse(p.toFile());
			
			Element root = doc.getDocumentElement();
			
			NodeList roots = root.getElementsByTagName("Route");
			
			for(int i = 0; i < roots.getLength(); i++){
				
				Route routeObj = new Route();
				Node route = roots.item(i);
				
				Element rootData = (Element) route;
				
				routeObj.setFlightNumber(Integer.parseInt(rootData.getElementsByTagName("FlightNumber").item(0).getTextContent()));
				
				routeObj.setDayOfWeek(rootData.getElementsByTagName("DayOfWeek").item(0).getTextContent());
				
				routeObj.setDepartureTime(LocalTime.parse(rootData.getElementsByTagName("DepartureTime").item(0).getTextContent()));
				
				routeObj.setDepartureAirport(rootData.getElementsByTagName("DepartureAirport").item(0).getTextContent());
				
				routeObj.setDepartureAirportCode(rootData.getElementsByTagName("DepartureAirportCode").item(0).getTextContent());
				
				routeObj.setArrivalTime(LocalTime.parse(rootData.getElementsByTagName("ArrivalTime").item(0).getTextContent()));
				
				routeObj.setArrivalAirport(rootData.getElementsByTagName("ArrivalAirport").item(0).getTextContent());
				
				routeObj.setArrivalAirportCode(rootData.getElementsByTagName("ArrivalAirportCode").item(0).getTextContent());
				
				routeObj.setDuration(java.time.Duration.parse(rootData.getElementsByTagName("Duration").item(0).getTextContent()));
					
				routes.add(routeObj);
			}
			
		
			
		}
		
		catch(Exception e) {
			throw new DataLoadingException(e);

		}
	}

	/**
	 * Unloads all of the crew currently loaded, ready to start again if needed
	 */
	@Override
	public void reset() {
		
		routes.clear();

	}

}
