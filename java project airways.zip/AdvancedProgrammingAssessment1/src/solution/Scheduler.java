package solution;
import java.time.LocalDate;
import java.util.List;
import java.util.Random;

import baseclasses.Aircraft;
import baseclasses.CabinCrew;
import baseclasses.DoubleBookedException;
import baseclasses.FlightInfo;
import baseclasses.IAircraftDAO;
import baseclasses.ICrewDAO;
import baseclasses.IPassengerNumbersDAO;
import baseclasses.IRouteDAO;
import baseclasses.IScheduler;
import baseclasses.InvalidAllocationException;
import baseclasses.Pilot;
import baseclasses.Schedule;
import baseclasses.SchedulerRunner;

public class Scheduler implements IScheduler {

	@Override
	public Schedule generateSchedule(IAircraftDAO AircraftDao, ICrewDAO CrewDao, IRouteDAO RouteDao, IPassengerNumbersDAO passengerNumbersDAO,
			LocalDate startDate, LocalDate endDate) {
		// TODO Auto-generated method stub
		
		Schedule scheduler = new Schedule(RouteDao, startDate, endDate);
		
		Random rand = new Random();
		
	//	List<FlightInfo> flightInfos = scheduler.getRemainingAllocations();
		
		int staffRequired;
		
		for(FlightInfo i: scheduler.getRemainingAllocations()) {
			
			while(true) {
			
				List<Aircraft> aircrafts = AircraftDao.getAllAircraft();
				
				try {
					
					Aircraft aircraft = aircrafts.get(rand.nextInt(aircrafts.size()));
					
					scheduler.allocateAircraftTo(aircraft, i);
					staffRequired = aircraft.getCabinCrewRequired();
					
					break;
				}
				
				catch(DoubleBookedException e) {
					
					e.printStackTrace();
				}
			
			}
			
			while(true) {
				
				List<Pilot> pilots = CrewDao.getAllPilots();
				
				try {
					
					scheduler.allocateCaptainTo(pilots.get(rand.nextInt(pilots.size())), i);
					scheduler.allocateFirstOfficerTo(pilots.get(rand.nextInt(pilots.size())),i);
					
					break;
					
				}
				
				catch(DoubleBookedException e) {
					e.printStackTrace();
				}
				
			}
			
			List<CabinCrew> cabinCrews = CrewDao.getAllCabinCrew(); 
			
			for(int j=0; j<staffRequired; j++) {
				
				while(true) {
					
					try {
						scheduler.allocateCabinCrewTo(cabinCrews.get(rand.nextInt(cabinCrews.size())), i);
						
						break;
					}
					
					catch(DoubleBookedException e) {
						e.printStackTrace();
					}
					
				}
				
			}
			
			try {
				
				scheduler.completeAllocationFor(i);
				
			}
			
			catch(InvalidAllocationException e) {
				
				e.printStackTrace();
				
			}
			
		}
		
		return scheduler;
	}

	@Override
	public void setSchedulerRunner(SchedulerRunner arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void stop() {
		// TODO Auto-generated method stub

	}

}
